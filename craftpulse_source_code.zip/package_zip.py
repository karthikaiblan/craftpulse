import os
import zipfile
import shutil

src_dir = r"C:\Users\KARTHI\.gemini\antigravity\scratch\craftpulse"
desktop_zip = r"C:\Users\KARTHI\OneDrive\Desktop\craftpulse_source_code.zip"
project_zip = os.path.join(src_dir, "craftpulse_source_code.zip")
artifact_zip = r"C:\Users\KARTHI\.gemini\antigravity\brain\49868423-28ea-4fa4-b024-6575bf647362\craftpulse_source_code.zip"

temp_zip = os.path.join(src_dir, "temp_craftpulse.zip")
if os.path.exists(temp_zip):
    os.remove(temp_zip)

exclude_dirs = {'.git', 'node_modules', '.gemini', '__pycache__', 'New folder'}
exclude_files = {
    'cloudflared.exe', 'craftpulse_source_code.zip', 'temp_craftpulse.zip',
    'chrome_check.txt', 'tunnel.log', 'ZEPHYR.zip', 'generate_devices.py'
}

with zipfile.ZipFile(temp_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(src_dir):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for f in files:
            if f in exclude_files:
                continue
            full_path = os.path.join(root, f)
            arcname = os.path.relpath(full_path, src_dir)
            zipf.write(full_path, arcname)

shutil.copy2(temp_zip, project_zip)
shutil.copy2(temp_zip, desktop_zip)
shutil.copy2(temp_zip, artifact_zip)
os.remove(temp_zip)

print(f"Zip created successfully! Size: {os.path.getsize(desktop_zip)} bytes")
