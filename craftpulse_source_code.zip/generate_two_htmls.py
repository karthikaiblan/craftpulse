import os

cwd = r"C:\Users\KARTHI\.gemini\antigravity\scratch\craftpulse"
index_template = os.path.join(cwd, "index.html")
laptop_file = os.path.join(cwd, "laptop.html")
mobile_file = os.path.join(cwd, "mobile.html")

with open(index_template, "r", encoding="utf-8") as f:
    template = f.read()

# 1. Generate laptop.html
laptop_content = template
laptop_content = laptop_content.replace(
    '<title>CraftPulse · Royal Neighbourhood Makers & Live Craft Queue</title>',
    '<title>CraftPulse · Laptop Edition</title>\n  <script>window.__CRAFTPULSE_DEVICE_MODE = "laptop";</script>'
)
# Update banner links in laptop.html
laptop_content = laptop_content.replace(
    'href="phone.html"', 'href="mobile.html"'
)
laptop_content = laptop_content.replace(
    'Phone View', 'Mobile View'
)

with open(laptop_file, "w", encoding="utf-8") as f:
    f.write(laptop_content)

# 2. Generate mobile.html
mobile_content = template
mobile_content = mobile_content.replace(
    '<title>CraftPulse · Royal Neighbourhood Makers & Live Craft Queue</title>',
    '<title>CraftPulse · Mobile Edition</title>\n  <script>window.__CRAFTPULSE_DEVICE_MODE = "phone";</script>'
)
mobile_content = mobile_content.replace(
    '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">',
    '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">'
)
mobile_content = mobile_content.replace(
    'href="phone.html"', 'href="mobile.html"'
)
mobile_content = mobile_content.replace(
    'Phone View', 'Mobile View'
)

with open(mobile_file, "w", encoding="utf-8") as f:
    f.write(mobile_content)

print(f"Generated laptop.html ({os.path.getsize(laptop_file)} bytes)")
print(f"Generated mobile.html ({os.path.getsize(mobile_file)} bytes)")
